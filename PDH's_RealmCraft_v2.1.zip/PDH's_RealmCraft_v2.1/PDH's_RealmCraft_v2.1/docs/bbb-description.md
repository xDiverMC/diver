# RealmCraft — Minecraft Server Website v2.1

A free, open-source Minecraft server website with a real Node.js backend. Live server status, a full vote tracking system, a real forum with accounts, a staff application system, and a config-driven storefront. All wired to one JSON config file so most customisation needs zero code changes.

Join discord(https://dsc.gg/minechuckle) for support, the code is clean and well-documented.

---

## Quick Start

```bash
npm install
```

Before starting the server, open `config/config.json` and set a real admin password:

```json
"backend": { "adminPassword": "pick-something-real-here" }
```

The server will refuse to start if this is left as the default placeholder — that's intentional.

Then run it:

```bash
npm start
```

Site is live at `http://localhost:3001`. Admin panel at `http://localhost:3001/admin.html`.

### `npm start` vs `npm run dev`

- **`npm start`** runs the server plainly with `node`. Use this for normal use and for production.
- **`npm run dev`** runs it through `nodemon`, which restarts the server automatically whenever you edit a backend file — useful while you're actively changing code.

One thing worth knowing: the server writes to a few JSON files at runtime (`config/players.json`, `config/forum.json`, `config/applications.json`) as people vote, post, and apply. `nodemon` is configured to **ignore** those specific files (see `nodemonConfig` in `package.json`) so that normal site activity doesn't trigger a restart — if it did, it would wipe every logged-in forum session on every single vote or forum post. If you ever add another file the server writes to at runtime, add it to that ignore list too, or `npm run dev` will misbehave in exactly this way.

---

## Pages

### Home — Live Server Status
Real-time widget showing online/offline state, player count, capacity, version, and votes cast today. Pings your server through mcsrvstat.us every 30 seconds with a silent fallback if that service is slow or down.

### Play — Game Mode Showcase
Four sections pulled from `config.json`'s `gameModes` array. Add, remove, or rename modes there — no HTML edits needed.

### Store — Ranks, Crates, Coins
Rank cards are rendered from the `ranks` array in `config.json` — add a rank, remove one, change prices or perks, and the page updates automatically. Crate keys and coin bundles are still a UI shell (see "What's Not Included" below) — wire the buy buttons to your Tebex checkout URLs.

### Vote — Full Tracking System
Players enter a username to load a live profile: streak, lifetime votes, reward progress, pending rewards. Voting opens the real vote-site link (once you've set one — see Configuration) and credits the vote on an honor-system basis, same as almost every free vote tracker without a paid Votifier proxy. If you want verified votes, use the `/api/minecraft/vote` webhook from a real NuVotifier listener instead — that path is the one to trust if verification matters to you.

### Forums — Real Accounts and Threads
Not a placeholder. Players can register (password-hashed with Node's built-in `scrypt`), sign in, post threads in any of the 11 categories, and reply. Sessions are token-based and live in memory — a server restart logs everyone out, which is a deliberate tradeoff for not requiring a database (see "What's Not Included").

### Staff — Team and Applications
Displays your team from the `staffTeam` array in `config.json`. Below it, a real application form: players submit a Minecraft username, age, position, experience, and reasoning. Submissions are validated, rate-limited (3 per hour per IP), and land in the admin panel for review.

### Admin Panel — `/admin.html`
Single shared password (`X-Admin-Password` header), not per-staff accounts. Tabs: overview stats, player table with per-player reset, vote simulator, live announcement editor, flavor message editor, staff application review (accept / reject / delete), and a security log.

**Security log** — records IPs that hit the vote rate limit or fail admin login. This is a visibility tool for the site owner, not an attack tool: it doesn't send data anywhere, and it exists so you can notice abuse patterns, not act on them for anyone else.

---

## Icons

Anywhere you see an `icon` field in `config.json` (ranks, achievements, levels, rewards, vote sites, leaderboard badges), you can use either:

- **A built-in icon name** for a clean vector look: `leaf`, `sword`, `shield`, `crown`, `fire`, `key`, `gem`, `bolt`, `star`, `trophy`, `gift`, `coin`, `moon`, `target`, `gear`, `castle`, `ballot`, and others — see `Icons` in `public/js/shared.js` for the full list.
- **Any literal emoji or text** — e.g. `"icon": "🔥"` — if you'd rather not pick from the built-in set.

Both work interchangeably; the renderer checks if the value matches a known icon name and falls back to displaying whatever you typed if it doesn't.

---

## Technical Specs

| Layer | Technology |
|---|---|
| Backend | Node.js 18+ · Express |
| Frontend | Pure HTML · CSS · Vanilla JS (no build step) |
| Database | JSON flat files — zero setup, no server to install |
| Auth | Node's built-in `crypto.scrypt` for password hashing, in-memory sessions |
| MC Status | Node's built-in `https` → mcsrvstat.us |
| Fonts | Syne Mono · Sora · JetBrains Mono |
| Dependencies | `express`, `cors` (2 packages) |

---

## API Endpoints

### Public
```
GET  /api/health                    Health check
GET  /api/config                    Full public config (drives the frontend)
GET  /api/status                    Live Minecraft server ping (cached 30s)
GET  /api/server                    Vote stats: today, weekly, top voter
GET  /api/player/:username          Player profile (auto-creates new players)
POST /api/vote                      Cast a vote, earn rewards, update streak
POST /api/claim-reward              Claim a pending reward
GET  /api/leaderboard                Top voters ranked
GET  /api/vote-sites                Vote sites with per-player cooldown status
POST /api/minecraft/vote            Plugin webhook (NuVotifier / Skript)
```

### Forum
```
POST /api/forum/register            Create an account
POST /api/forum/login               Sign in, returns a session token
POST /api/forum/logout              Invalidate the current session
GET  /api/forum/session             Check current session state
GET  /api/forum/categories          List categories
GET  /api/forum/stats               Real post/thread/member counts
GET  /api/forum/threads             List threads (optional ?category=)
GET  /api/forum/threads/:id         Thread with its posts
POST /api/forum/threads             Create a thread (requires session token)
POST /api/forum/threads/:id/posts   Reply to a thread (requires session token)
```

### Staff
```
GET  /api/staff/team                Staff team list
GET  /api/staff/positions           Open positions
POST /api/staff/apply               Submit an application (rate-limited)
```

### Admin (`X-Admin-Password` header required)
```
GET  /api/admin/stats                     Aggregated dashboard stats
GET  /api/admin/players                   All player records
POST /api/admin/reset-player              Reset all stats for a player
POST /api/admin/reset-streak              Reset streak only
POST /api/admin/simulate-vote             Trigger a vote for testing
POST /api/admin/update-announcement       Edit the announcement bar live
POST /api/admin/update-messages           Edit flavor messages
GET  /api/admin/applications              List staff applications
POST /api/admin/applications/:id/status   Accept / reject an application
DELETE /api/admin/applications/:id        Delete an application
GET  /api/admin/security-log              Rate-limit / failed-auth events
```

---

## Vote System Features

- **Streak tracking** — 48-hour window with calendar-day logic. Miss a day and the streak resets to 1.
- **Weekly reset** — `weeklyVotes` zeros automatically on the ISO week boundary.
- **Per-site cooldown** — each vote site tracked separately.
- **Configurable rewards** — vote-interval rewards and streak milestones, both defined in `config.json`.
- **10 achievements** — conditions are `votes>=N`, `streak>=N`, or `allSites`, computed live.
- **10-level progression** — driven by lifetime votes.
- **Pending rewards** — tracks earned vs claimed, with a one-click claim button.

---

## Minecraft Plugin Integration

```
POST /api/minecraft/vote
Content-Type: application/json

{ "player": "Steve", "site": "planetmc", "secret": "your-secret" }
```

**Skript example:**
```
on vote:
    make a POST request to "http://your-api.com/api/minecraft/vote"
      with header "Content-Type: application/json"
      with body "{""player"":""%player%"",""site"":""planetmc"",""secret"":""YOUR_SECRET""}"
```

Supports NuVotifier listeners, VotingPlugin command triggers, and any HTTP-capable plugin or script. Set `backend.webhookSecret` in `config.json` to require the secret.

---

## Configuration

Almost everything lives in `config/config.json`.

```json
{
  "server": {
    "name": "YourServer",
    "ip": "play.yourserver.net",
    "discord": "https://discord.gg/yourserver",
    "logoUrl": "",
    "faviconUrl": ""
  },
  "ranks": [
    { "id": "wanderer", "name": "Wanderer", "icon": "leaf", "price": 0, "current": true, "features": ["..."] }
  ],
  "voteSites": [
    { "id": "planetmc", "name": "Planet Minecraft", "url": "", "reward": "Vote Key + 1,000 Coins" }
  ],
  "staffTeam": [
    { "username": "YourName", "role": "Owner", "tagline": "Runs the network." }
  ],
  "staffPositions": [
    { "id": "moderator", "name": "Moderator", "description": "Chat moderation, reports, support." }
  ],
  "forumCategories": [
    { "id": "general", "name": "General Discussion", "group": "The Community" }
  ]
}
```

Things worth setting before you go live:
- `voteSites[].url` — currently blank on every entry. Vote buttons stay disabled until you add your real listing links.
- `backend.adminPassword` — the server won't start with the default.
- `server.logoUrl` / `server.faviconUrl` — optional. Leave blank to use the default "RC" text mark and browser default favicon.

---

## Deployment — 15 Minutes

### Backend (Render — free tier)
1. Push to GitHub
2. Render → New Web Service → connect repo
3. Build command: `npm install`
4. Start command: `node backend/server.js`

### Frontend (Cloudflare Pages — free)
1. Set your backend URL in `public/js/api.js` (`window.REALMCRAFT_API`, one line, clearly marked)
2. Cloudflare Pages → new project → output directory: `public`

### Self-Hosted (VPS / Pterodactyl)
```bash
npm install
PORT=80 node backend/server.js
# or: pm2 start backend/server.js --name realmcraft
```

---

## What's Not Included 

- **No real payment processing** — the Store's crate/coin buttons are a UI shell. Wire them to Tebex.
- **No persistent forum sessions** — sessions live in memory. A server restart logs everyone out. Adding persistence would mean adding a real database, which conflicts with this project's "zero setup" design.
- **No verified vote clicks** — website voting is honor-system (open link, credit immediately), same as most free vote trackers. The `/api/minecraft/vote` webhook is the verified path if you need one.
- **No WebSocket real-time** — the leaderboard and thread lists poll, they don't push.
- **No per-staff admin accounts or audit log** — the admin panel uses one shared password. If you need per-staff accounts and an action log, that's a real scope increase (proper auth, permissions, logging) beyond what a free template ships with by default.

---

## Requirements

- Node.js 18 or newer
- Any Node.js hosting (Render, Railway, VPS, Pterodactyl)
- A Minecraft server with a public IP or domain (for the live status widget)

---

## File Structure

```
RealmCraft/
├── backend/
│   ├── server.js              Express app bootstrap, route mounting
│   ├── config.js              Config loader, validates admin password on boot
│   ├── db.js                  Player data storage
│   ├── forumDb.js             Forum accounts/threads/posts storage
│   ├── forumSessions.js       In-memory session tokens
│   ├── staffDb.js             Staff application storage
│   ├── mcStatus.js            Live Minecraft server status polling
│   ├── voteLogic.js           Streaks, rewards, achievements, levels
│   ├── middleware/
│   │   ├── adminAuth.js       Timing-safe admin password check
│   │   └── rateLimit.js       Rate limiting + security event log
│   └── routes/
│       ├── public.js          Status, config, vote, leaderboard, webhook
│       ├── admin.js           Stats, players, applications, security log
│       ├── forum.js           Register, login, threads, posts
│       └── staff.js           Team, positions, applications
├── config/
│   ├── config.json            Edit this to customise almost everything
│   ├── players.json           Vote database (auto-managed)
│   ├── forum.json             Forum accounts/threads (auto-managed)
│   └── applications.json      Staff applications (auto-managed)
├── public/
│   ├── index.html             Home + live status widget
│   ├── play.html              Game mode showcase
│   ├── store.html             Ranks, crates, coins
│   ├── vote.html              Full vote system
│   ├── forums.html            Real forum: accounts, threads, replies
│   ├── staff.html             Staff team + application form
│   ├── admin.html             Admin panel
│   ├── css/global.css         Design system
│   └── js/
│       ├── api.js             API client (set your backend URL here)
│       └── shared.js          Nav, footer, icons, config injection
├── package.json
└── README.md
```

---

## License

**Free version.** Use on as many of your own servers as you like. Do not resell or redistribute as a standalone product.

*© 2026 RealmCraft · PathumDH (Kraken Hive Labs)*